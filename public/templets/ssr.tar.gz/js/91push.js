
//百度统计代码

var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?2d9e045958ce99591356a5d8641bfaec";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();




//百度推送代码

(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();


//360PC推送代码

(function(){
var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?be0c772cd43bd25b5e1ef365705c0f91":"https://jspassport.ssl.qhimg.com/11.0.1.js?be0c772cd43bd25b5e1ef365705c0f91";
document.write('<script src="' + src + '" id="sozz"><\/script>');
})();



//360手机推送代码

(function(){
var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?1aac1a7b047246545aeb44adb697a960":"https://jspassport.ssl.qhimg.com/11.0.1.js?1aac1a7b047246545aeb44adb697a960";
document.write('<script src="' + src + '" id="sozz"><\/script>');
})();


//CNZZ统计

var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1272888778'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s22.cnzz.com/z_stat.php%3Fid%3D1272888778' type='text/javascript'%3E%3C/script%3E"));
//53客服
(function() {var _53code = document.createElement("script");_53code.src = "https://tb.53kf.com/code/code/10174837/1";var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(_53code, s);})();










