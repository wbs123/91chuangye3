
//百度统计代码

<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?8fae0b6e9409df292c396670b11535ba";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>



//百度推送代码

<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>

//360PC推送代码

<script>(function(){
var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?be0c772cd43bd25b5e1ef365705c0f91":"https://jspassport.ssl.qhimg.com/11.0.1.js?be0c772cd43bd25b5e1ef365705c0f91";
document.write('<script src="' + src + '" id="sozz"><\/script>');
})();
</script>


//360手机推送代码

<script>(function(){
var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?1aac1a7b047246545aeb44adb697a960":"https://jspassport.ssl.qhimg.com/11.0.1.js?1aac1a7b047246545aeb44adb697a960";
document.write('<script src="' + src + '" id="sozz"><\/script>');
})();
</script>

//CNZZ统计

<div style="display:none;">
<script src="https://s22.cnzz.com/z_stat.php?id=1272888778&web_id=1272888778" language="JavaScript"></script>
</div>











